import webpush from 'web-push';
import type { SavePushSubscriptionRequest, SendPushNotificationRequest } from '@mental-load/contracts';

export interface StoredPushSubscription {
  endpoint: string;
  keys: { p256dh: string; auth: string };
  memberId?: string;
  createdAt: string;
}

export interface PushNotificationPayload {
  title: string;
  body: string;
  url?: string;
  icon?: string;
  badge?: string;
}

export class PushService {
  private readonly subscriptions = new Map<string, StoredPushSubscription>();
  private vapidInitialized = false;

  private ensureVapid(): void {
    if (this.vapidInitialized) return;
    const subject = process.env.VAPID_SUBJECT ?? 'mailto:admin@mental-load.local';
    const publicKey = process.env.VAPID_PUBLIC_KEY ?? '';
    const privateKey = process.env.VAPID_PRIVATE_KEY ?? '';
    if (publicKey && privateKey) {
      webpush.setVapidDetails(subject, publicKey, privateKey);
      this.vapidInitialized = true;
    }
  }

  getPublicKey(): string {
    return process.env.VAPID_PUBLIC_KEY ?? '';
  }

  saveSubscription(req: SavePushSubscriptionRequest): void {
    this.subscriptions.set(req.endpoint, {
      endpoint: req.endpoint,
      keys: req.keys,
      memberId: req.memberId,
      createdAt: new Date().toISOString(),
    });
  }

  removeSubscription(endpoint: string): void {
    this.subscriptions.delete(endpoint);
  }

  listSubscriptions(memberId?: string): StoredPushSubscription[] {
    const all = [...this.subscriptions.values()];
    if (!memberId) return all;
    return all.filter((s) => s.memberId === memberId);
  }

  async sendToAll(req: SendPushNotificationRequest): Promise<number> {
    this.ensureVapid();
    const targets = req.memberId
      ? this.listSubscriptions(req.memberId)
      : this.listSubscriptions();

    if (targets.length === 0) return 0;

    const payload = JSON.stringify({
      title: req.title,
      body: req.body,
      url: req.url ?? '/',
      icon: '/icon-192.png',
      badge: '/badge-72.png',
    } satisfies PushNotificationPayload);

    let sent = 0;
    await Promise.all(
      targets.map(async (sub) => {
        try {
          await webpush.sendNotification(
            { endpoint: sub.endpoint, keys: sub.keys },
            payload,
          );
          sent += 1;
        } catch (err: unknown) {
          const status = (err as { statusCode?: number }).statusCode;
          if (status === 410 || status === 404) {
            this.subscriptions.delete(sub.endpoint);
          }
        }
      }),
    );
    return sent;
  }
}
