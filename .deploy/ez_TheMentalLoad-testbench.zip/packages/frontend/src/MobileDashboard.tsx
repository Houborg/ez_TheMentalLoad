import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import type {
  Calendar,
  Entry,
  FoodPlanDay,
  FoodPlanItem,
  ListFoodPlanResponse,
  Member,
} from '@mental-load/contracts';

// ─── helpers ─────────────────────────────────────────────────────────────────

function apiUrl(path: string): string {
  return path;
}

function dateKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

function entryDateKey(iso: string): string {
  return dateKey(new Date(iso));
}

function fmtTime(iso: string): string {
  return new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
}

function fmtDay(iso: string): string {
  return new Intl.DateTimeFormat(undefined, { weekday: 'short', day: 'numeric', month: 'short' }).format(new Date(iso));
}

function toBaseId(id: string): string {
  return id.split(':')[0];
}

function nextHourISO(dateKey: string): { start: string; end: string } {
  const now = new Date();
  const [y, m, d] = dateKey.split('-').map(Number);
  const base = new Date(y, (m || 1) - 1, d || 1, now.getHours() + 1, 0, 0, 0);
  return {
    start: base.toISOString(),
    end: new Date(base.getTime() + 3_600_000).toISOString(),
  };
}

function toLocalDatetime(iso: string): string {
  const d = new Date(iso);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
}

function buildAgendaDays(n = 7): string[] {
  const days: string[] = [];
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  for (let i = 0; i < n; i++) {
    days.push(dateKey(d));
    d.setDate(d.getDate() + 1);
  }
  return days;
}

function currentWeekMonday(): string {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  const diff = d.getDay() === 0 ? -6 : 1 - d.getDay();
  d.setDate(d.getDate() + diff);
  return dateKey(d);
}

const FOOD_DAYS: FoodPlanDay[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const MEMBER_PALETTE = ['#4d8fd6', '#d68ab0', '#a76edb', '#43b887', '#5966d4', '#d48954'];

// ─── Push helpers ─────────────────────────────────────────────────────────────

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}

async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return null;
  try {
    return await navigator.serviceWorker.register('/sw.js', { scope: '/' });
  } catch {
    return null;
  }
}

async function subscribeToPush(reg: ServiceWorkerRegistration, vapidKey: string): Promise<PushSubscription | null> {
  try {
    const existing = await reg.pushManager.getSubscription();
    if (existing) return existing;
    return await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidKey) as BufferSource,
    });
  } catch {
    return null;
  }
}

// ─── Types ────────────────────────────────────────────────────────────────────

type MobileTab = 'today' | 'agenda' | 'food' | 'notify';

interface EventDraft {
  entryId?: string;
  dateKey: string;
  title: string;
  ownerMemberId: string;
  calendarId: string;
  startTime: string;
  endTime: string;
  allDay: boolean;
  taskLines: string;
  existingTasks: Array<{ id: string; title: string; status: Entry['status'] }>;
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function MobileDashboard({ onSwitchToDesktop }: { onSwitchToDesktop: () => void }) {
  const [members, setMembers] = useState<Member[]>([]);
  const [calendars, setCalendars] = useState<Calendar[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [foodPlan, setFoodPlan] = useState<Record<FoodPlanDay, FoodPlanItem | undefined>>({
    monday: undefined, tuesday: undefined, wednesday: undefined,
    thursday: undefined, friday: undefined, saturday: undefined, sunday: undefined,
  });
  const [tab, setTab] = useState<MobileTab>('today');
  const [status, setStatus] = useState('');
  const [eventDraft, setEventDraft] = useState<EventDraft | null>(null);
  const [foodDraftDay, setFoodDraftDay] = useState<FoodPlanDay | null>(null);
  const [foodDraftName, setFoodDraftName] = useState('');

  // Push state
  const [pushSupported, setPushSupported] = useState(false);
  const [pushSubscribed, setPushSubscribed] = useState(false);
  const [pushBusy, setPushBusy] = useState(false);
  const [vapidKey, setVapidKey] = useState('');
  const [notifyTitle, setNotifyTitle] = useState('');
  const [notifyBody, setNotifyBody] = useState('');
  const swRegRef = useRef<ServiceWorkerRegistration | null>(null);

  const todayKey = useMemo(() => dateKey(new Date()), []);
  const agendaDays = useMemo(() => buildAgendaDays(14), []);
  const weekStart = useMemo(() => currentWeekMonday(), []);

  const memberById = useMemo(() =>
    members.reduce<Record<string, Member>>((acc, m) => { acc[m.id] = m; return acc; }, {}),
    [members],
  );

  const colorById = useMemo(() =>
    members.reduce<Record<string, string>>((acc, m, i) => {
      acc[m.id] = MEMBER_PALETTE[i % MEMBER_PALETTE.length];
      return acc;
    }, {}),
    [members],
  );

  const entriesByDate = useMemo(() =>
    entries.reduce<Record<string, Entry[]>>((acc, e) => {
      const k = entryDateKey(e.startTime);
      if (!acc[k]) acc[k] = [];
      acc[k].push(e);
      return acc;
    }, {}),
    [entries],
  );

  const todayEvents = useMemo(() =>
    (entriesByDate[todayKey] ?? []).filter((e) => e.type === 'event').sort((a, b) => a.startTime.localeCompare(b.startTime)),
    [entriesByDate, todayKey],
  );

  const todayTasks = useMemo(() =>
    (entriesByDate[todayKey] ?? []).filter((e) => e.type === 'task').sort((a, b) => a.startTime.localeCompare(b.startTime)),
    [entriesByDate, todayKey],
  );

  // ── data loading ──────────────────────────────────────────────────────────

  const load = useCallback(async () => {
    try {
      const now = new Date();
      const to = new Date(now.getTime() + 14 * 86_400_000);
      const q = new URLSearchParams({ from: now.toISOString(), to: to.toISOString() });
      const [dash, occ, fp] = await Promise.all([
        fetch(apiUrl('/api/v1/dashboard')),
        fetch(apiUrl(`/api/v1/entries/occurrences?${q}`)),
        fetch(apiUrl(`/api/v1/food-plan?weekStart=${weekStart}`)),
      ]);
      if (dash.ok) {
        const d = await dash.json() as { members: Member[]; calendars: Calendar[] };
        setMembers(d.members);
        setCalendars(d.calendars);
      }
      if (occ.ok) {
        setEntries((await occ.json()) as Entry[]);
      }
      if (fp.ok) {
        const fpData = (await fp.json()) as ListFoodPlanResponse;
        const mapped: Record<FoodPlanDay, FoodPlanItem | undefined> = {
          monday: undefined, tuesday: undefined, wednesday: undefined,
          thursday: undefined, friday: undefined, saturday: undefined, sunday: undefined,
        };
        for (const item of fpData.items) mapped[item.day] = item;
        setFoodPlan(mapped);
      }
    } catch {
      setStatus('Could not load data');
    }
  }, [weekStart]);

  useEffect(() => { void load(); }, [load]);

  // ── live ws ───────────────────────────────────────────────────────────────

  useEffect(() => {
    const wsProto = location.protocol === 'https:' ? 'wss' : 'ws';
    const ws = new WebSocket(`${wsProto}://${location.host}/ws`);
    ws.onmessage = () => { void load(); };
    return () => ws.close();
  }, [load]);

  // ── push bootstrap ────────────────────────────────────────────────────────

  useEffect(() => {
    const init = async () => {
      const reg = await registerServiceWorker();
      if (!reg) { setPushSupported(false); return; }
      swRegRef.current = reg;
      setPushSupported(true);

      try {
        const res = await fetch(apiUrl('/api/v1/push/vapid-public-key'));
        if (res.ok) {
          const data = await res.json() as { publicKey: string };
          setVapidKey(data.publicKey);
        }
      } catch { /* vapid not configured */ }

      const existing = await reg.pushManager.getSubscription().catch(() => null);
      setPushSubscribed(!!existing);
    };
    void init();
  }, []);

  // ── push subscribe/unsubscribe ─────────────────────────────────────────────

  const handlePushToggle = async () => {
    if (!swRegRef.current || !vapidKey) {
      setStatus('Push not configured on server – add VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY env vars');
      return;
    }
    setPushBusy(true);
    try {
      if (pushSubscribed) {
        const sub = await swRegRef.current.pushManager.getSubscription();
        if (sub) {
          await sub.unsubscribe();
          await fetch(apiUrl('/api/v1/push/unsubscribe'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ endpoint: sub.endpoint }),
          });
        }
        setPushSubscribed(false);
        setStatus('Push notifications disabled');
      } else {
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') { setStatus('Permission denied'); return; }
        const sub = await subscribeToPush(swRegRef.current, vapidKey);
        if (!sub) { setStatus('Could not subscribe'); return; }
        const j = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
        await fetch(apiUrl('/api/v1/push/subscribe'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ endpoint: j.endpoint, keys: j.keys }),
        });
        setPushSubscribed(true);
        setStatus('Push notifications enabled');
      }
    } finally {
      setPushBusy(false);
    }
  };

  const handleSendPush = async () => {
    if (!notifyTitle.trim()) { setStatus('Title is required'); return; }
    const res = await fetch(apiUrl('/api/v1/push/send'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: notifyTitle.trim(), body: notifyBody.trim() || ' ' }),
    });
    const data = await res.json() as { sent: number; message: string };
    setStatus(data.message);
    setNotifyTitle('');
    setNotifyBody('');
  };

  // ── event modal helpers ───────────────────────────────────────────────────

  const openNewEvent = (dk: string) => {
    const times = nextHourISO(dk);
    setEventDraft({
      dateKey: dk,
      title: '',
      ownerMemberId: members[0]?.id ?? '',
      calendarId: calendars[0]?.id ?? '',
      startTime: toLocalDatetime(times.start),
      endTime: toLocalDatetime(times.end),
      allDay: false,
      taskLines: '',
      existingTasks: [],
    });
  };

  const openExisting = (entry: Entry) => {
    const baseId = toBaseId(entry.id);
    const linkedTasks = entries
      .filter((e) => e.type === 'task' && (e.parentEntryId === entry.id || e.parentEntryId === baseId))
      .sort((a, b) => a.startTime.localeCompare(b.startTime));
    setEventDraft({
      entryId: baseId,
      dateKey: entryDateKey(entry.startTime),
      title: entry.title,
      ownerMemberId: entry.ownerMemberId,
      calendarId: entry.calendarId,
      startTime: toLocalDatetime(entry.startTime),
      endTime: toLocalDatetime(entry.endTime),
      allDay: entry.allDay,
      taskLines: '',
      existingTasks: linkedTasks.map((t) => ({ id: toBaseId(t.id), title: t.title, status: t.status })),
    });
  };

  const saveEvent = async () => {
    if (!eventDraft || !eventDraft.title.trim()) { setStatus('Title required'); return; }
    const payload = {
      title: eventDraft.title.trim(),
      type: 'event' as const,
      ownerMemberId: eventDraft.ownerMemberId,
      calendarId: eventDraft.calendarId,
      startTime: new Date(eventDraft.startTime).toISOString(),
      endTime: new Date(eventDraft.endTime).toISOString(),
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      allDay: eventDraft.allDay,
    };
    const res = await fetch(
      eventDraft.entryId ? apiUrl(`/api/v1/entries/${eventDraft.entryId}`) : apiUrl('/api/v1/entries'),
      { method: eventDraft.entryId ? 'PATCH' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) },
    );
    if (!res.ok) { setStatus('Could not save event'); return; }
    const saved = (await res.json()) as Entry;

    // sync tasks
    const taskTitles = eventDraft.taskLines.split('\n').map((l) => l.trim()).filter(Boolean);
    for (const title of taskTitles) {
      await fetch(apiUrl('/api/v1/entries'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title, type: 'task',
          ownerMemberId: saved.ownerMemberId,
          calendarId: saved.calendarId,
          startTime: saved.startTime,
          endTime: saved.endTime,
          timezone: saved.timezone,
          allDay: saved.allDay,
          parentEntryId: toBaseId(saved.id),
          reminders: [],
        }),
      });
    }
    setEventDraft(null);
    setStatus(eventDraft.entryId ? 'Event updated' : 'Event created');
    await load();
  };

  const deleteEvent = async () => {
    if (!eventDraft?.entryId) return;
    const baseId = toBaseId(eventDraft.entryId);
    const linked = entries.filter((e) => e.type === 'task' && (e.parentEntryId === eventDraft.entryId || e.parentEntryId === baseId));
    for (const t of linked) await fetch(apiUrl(`/api/v1/entries/${toBaseId(t.id)}`), { method: 'DELETE' });
    const res = await fetch(apiUrl(`/api/v1/entries/${baseId}`), { method: 'DELETE' });
    if (!res.ok) { setStatus('Could not delete'); return; }
    setEventDraft(null);
    setStatus('Deleted');
    await load();
  };

  const toggleTask = async (taskId: string, done: boolean) => {
    await fetch(apiUrl(`/api/v1/entries/${toBaseId(taskId)}`), {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: done ? 'completed' : 'active' }),
    });
    setEventDraft((cur) => cur ? {
      ...cur,
      existingTasks: cur.existingTasks.map((t) => t.id === taskId ? { ...t, status: done ? 'completed' : 'active' } : t),
    } : cur);
    await load();
  };

  const deleteTask = async (taskId: string) => {
    await fetch(apiUrl(`/api/v1/entries/${toBaseId(taskId)}`), { method: 'DELETE' });
    setEventDraft((cur) => cur ? { ...cur, existingTasks: cur.existingTasks.filter((t) => t.id !== taskId) } : cur);
  };

  const saveFoodDay = async () => {
    if (!foodDraftDay || !foodDraftName.trim()) return;
    await fetch(apiUrl('/api/v1/food-plan'), {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ weekStart, day: foodDraftDay, dishName: foodDraftName.trim(), groceryList: [] }),
    });
    setFoodDraftDay(null);
    setFoodDraftName('');
    await load();
  };

  // ─────────────────────────────────────────────────────────────────────────
  // Render helpers
  // ─────────────────────────────────────────────────────────────────────────

  const todayLabel = new Intl.DateTimeFormat(undefined, { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date());

  return (
    <div className="md-shell">
      {/* ── Top bar ── */}
      <header className="md-topbar">
        <div className="md-topbar-left">
          <span className="md-eyebrow">MentalLoad</span>
          <h1 className="md-title">Family</h1>
        </div>
        <div className="md-topbar-right">
          <button type="button" className="md-icon-btn" title="Switch to desktop" onClick={onSwitchToDesktop}>
            🖥
          </button>
          <button type="button" className="md-icon-btn" onClick={() => { void load(); }}>
            🔄
          </button>
        </div>
      </header>

      {/* ── Status toast ── */}
      {status ? (
        <div className="md-toast" role="status" onClick={() => setStatus('')}>{status}</div>
      ) : null}

      {/* ── Content ── */}
      <main className="md-content">

        {/* TODAY */}
        {tab === 'today' && (
          <div className="md-page">
            <div className="md-section-header">
              <span className="md-section-label">Today</span>
              <span className="md-section-sub">{todayLabel}</span>
            </div>

            {/* Member strip */}
            <div className="md-members-strip">
              {members.map((m) => (
                <div key={m.id} className="md-member-chip" style={{ '--chip-color': colorById[m.id] } as CSSProperties}>
                  <span className="md-member-avatar">{m.name.slice(0, 1).toUpperCase()}</span>
                  <span className="md-member-name">{m.name}</span>
                </div>
              ))}
            </div>

            {/* Today events */}
            <div className="md-card-section">
              <div className="md-card-header">
                <span>Events</span>
                <button type="button" className="md-add-btn" onClick={() => openNewEvent(todayKey)}>+ Add</button>
              </div>
              {todayEvents.length === 0 ? (
                <p className="md-empty">No events today</p>
              ) : (
                <div className="md-event-list">
                  {todayEvents.map((e) => (
                    <button key={e.id} type="button" className="md-event-card" onClick={() => openExisting(e)}
                      style={{ '--event-color': colorById[e.ownerMemberId] ?? '#8fa1b7' } as CSSProperties}>
                      <div className="md-event-time">{fmtTime(e.startTime)}</div>
                      <div className="md-event-info">
                        <strong>{e.title}</strong>
                        <span className="md-event-owner">{memberById[e.ownerMemberId]?.name ?? ''}</span>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Today tasks */}
            <div className="md-card-section">
              <div className="md-card-header">
                <span>Tasks</span>
              </div>
              {todayTasks.length === 0 ? (
                <p className="md-empty">No tasks today</p>
              ) : (
                <div className="md-task-list">
                  {todayTasks.map((t) => (
                    <div key={t.id} className="md-task-row">
                      <input
                        type="checkbox"
                        className="md-task-check"
                        checked={t.status === 'completed'}
                        onChange={(ev) => { void toggleTask(t.id, ev.target.checked); }}
                      />
                      <span className={t.status === 'completed' ? 'md-task-title done' : 'md-task-title'}>{t.title}</span>
                      <span className="md-task-owner" style={{ color: colorById[t.ownerMemberId] }}>
                        {memberById[t.ownerMemberId]?.name ?? ''}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Food today */}
            {(() => {
              const dayName = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'][new Date().getDay()] as FoodPlanDay;
              const meal = foodPlan[dayName];
              return (
                <div className="md-card-section">
                  <div className="md-card-header">
                    <span>Tonight's dinner</span>
                    <button type="button" className="md-add-btn" onClick={() => { setFoodDraftDay(dayName); setFoodDraftName(meal?.dishName ?? ''); }}>Edit</button>
                  </div>
                  {meal?.dishName ? (
                    <div className="md-dinner-chip">{meal.dishName}</div>
                  ) : (
                    <p className="md-empty">No meal planned</p>
                  )}
                </div>
              );
            })()}
          </div>
        )}

        {/* AGENDA */}
        {tab === 'agenda' && (
          <div className="md-page">
            <div className="md-section-header">
              <span className="md-section-label">Agenda</span>
              <span className="md-section-sub">Next 14 days</span>
            </div>
            {agendaDays.map((dk) => {
              const dayEntries = (entriesByDate[dk] ?? []).filter((e) => e.type !== 'task').sort((a, b) => a.startTime.localeCompare(b.startTime));
              const isToday = dk === todayKey;
              return (
                <div key={dk} className={isToday ? 'md-agenda-day md-agenda-today' : 'md-agenda-day'}>
                  <div className="md-agenda-day-header">
                    <strong>{fmtDay(`${dk}T12:00:00`)}</strong>
                    {isToday ? <span className="md-today-badge">Today</span> : null}
                    <button type="button" className="md-add-btn" onClick={() => openNewEvent(dk)}>+</button>
                  </div>
                  {dayEntries.length === 0 ? (
                    <p className="md-empty">Free</p>
                  ) : (
                    <div className="md-event-list">
                      {dayEntries.map((e) => (
                        <button key={e.id} type="button" className="md-event-card" onClick={() => openExisting(e)}
                          style={{ '--event-color': colorById[e.ownerMemberId] ?? '#8fa1b7' } as CSSProperties}>
                          <div className="md-event-time">{fmtTime(e.startTime)}</div>
                          <div className="md-event-info">
                            <strong>{e.title}</strong>
                            <span className="md-event-owner">{memberById[e.ownerMemberId]?.name ?? ''}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* FOOD PLAN */}
        {tab === 'food' && (
          <div className="md-page">
            <div className="md-section-header">
              <span className="md-section-label">Food Plan</span>
              <span className="md-section-sub">This week</span>
            </div>
            <div className="md-food-grid">
              {FOOD_DAYS.map((day) => {
                const item = foodPlan[day];
                return (
                  <button key={day} type="button" className={item?.dishName ? 'md-food-card has-dish' : 'md-food-card'}
                    onClick={() => { setFoodDraftDay(day); setFoodDraftName(item?.dishName ?? ''); }}>
                    <span className="md-food-day">{day.slice(0, 3).toUpperCase()}</span>
                    <span className="md-food-emoji">{item?.dishName ? '🍽' : '+'}</span>
                    <span className="md-food-name">{item?.dishName ?? 'Add meal'}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* PUSH NOTIFICATIONS */}
        {tab === 'notify' && (
          <div className="md-page">
            <div className="md-section-header">
              <span className="md-section-label">Push Notifications</span>
              <span className="md-section-sub">Actionable family alerts</span>
            </div>

            {/* Subscribe / unsubscribe */}
            <div className="md-card-section">
              <div className="md-card-header"><span>This device</span></div>
              <div className="md-push-status">
                {!pushSupported ? (
                  <p className="md-empty">Push not supported in this browser</p>
                ) : (
                  <>
                    <span className={pushSubscribed ? 'md-push-dot active' : 'md-push-dot'} />
                    <span>{pushSubscribed ? 'Subscribed' : 'Not subscribed'}</span>
                    <button
                      type="button"
                      className={pushSubscribed ? 'md-push-btn unsubscribe' : 'md-push-btn subscribe'}
                      disabled={pushBusy || !vapidKey}
                      onClick={() => { void handlePushToggle(); }}
                    >
                      {pushBusy ? '…' : pushSubscribed ? 'Disable' : 'Enable notifications'}
                    </button>
                  </>
                )}
                {!vapidKey && pushSupported ? (
                  <p className="md-push-hint">Set VAPID_PUBLIC_KEY + VAPID_PRIVATE_KEY on the server to enable push.</p>
                ) : null}
              </div>
            </div>

            {/* Send push to all devices */}
            <div className="md-card-section">
              <div className="md-card-header"><span>Send to all devices</span></div>
              <div className="md-push-form">
                <input
                  className="md-input"
                  placeholder="Notification title"
                  value={notifyTitle}
                  onChange={(ev) => setNotifyTitle(ev.target.value)}
                />
                <textarea
                  className="md-input md-textarea"
                  placeholder="Message body"
                  rows={3}
                  value={notifyBody}
                  onChange={(ev) => setNotifyBody(ev.target.value)}
                />
                <button
                  type="button"
                  className="md-push-send-btn"
                  disabled={!notifyTitle.trim()}
                  onClick={() => { void handleSendPush(); }}
                >
                  Send push notification 🔔
                </button>
              </div>
            </div>

            {/* Quick reminder shortcuts */}
            <div className="md-card-section">
              <div className="md-card-header"><span>Quick reminders</span></div>
              <div className="md-quick-pushes">
                {[
                  { emoji: '🚌', text: 'Time to get ready for school!' },
                  { emoji: '🍽', text: "Dinner is ready – come to the table!" },
                  { emoji: '🛏', text: 'Bedtime reminder for the kids 😴' },
                  { emoji: '🗒', text: "Don't forget tomorrow's events!" },
                ].map((q) => (
                  <button
                    key={q.text}
                    type="button"
                    className="md-quick-push-btn"
                    disabled={!pushSubscribed}
                    onClick={() => {
                      setNotifyTitle(q.emoji);
                      setNotifyBody(q.text);
                    }}
                  >
                    <span className="md-quick-push-emoji">{q.emoji}</span>
                    <span>{q.text}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

      </main>

      {/* ── Bottom nav ── */}
      <nav className="md-bottomnav">
        {([
          { key: 'today', icon: '🏠', label: 'Today' },
          { key: 'agenda', icon: '📅', label: 'Agenda' },
          { key: 'food', icon: '🍴', label: 'Food' },
          { key: 'notify', icon: '🔔', label: 'Notify' },
        ] as Array<{ key: MobileTab; icon: string; label: string }>).map((item) => (
          <button
            key={item.key}
            type="button"
            className={tab === item.key ? 'md-nav-item active' : 'md-nav-item'}
            onClick={() => setTab(item.key)}
          >
            <span className="md-nav-icon">{item.icon}</span>
            <span className="md-nav-label">{item.label}</span>
          </button>
        ))}
      </nav>

      {/* ── Event modal ── */}
      {eventDraft && (
        <div className="md-modal-backdrop" onClick={() => setEventDraft(null)}>
          <div className="md-modal" onClick={(ev) => ev.stopPropagation()}>
            <div className="md-modal-header">
              <h2>{eventDraft.entryId ? 'Edit Event' : 'New Event'}</h2>
              <button type="button" className="md-modal-close" onClick={() => setEventDraft(null)}>✕</button>
            </div>
            <div className="md-modal-body">
              <input className="md-input" placeholder="Event title" value={eventDraft.title}
                onChange={(ev) => setEventDraft((c) => c ? { ...c, title: ev.target.value } : c)} />
              <label className="md-label">
                Member
                <select className="md-input" value={eventDraft.ownerMemberId}
                  onChange={(ev) => setEventDraft((c) => c ? { ...c, ownerMemberId: ev.target.value } : c)}>
                  {members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
                </select>
              </label>
              <label className="md-label">
                Calendar
                <select className="md-input" value={eventDraft.calendarId}
                  onChange={(ev) => setEventDraft((c) => c ? { ...c, calendarId: ev.target.value } : c)}>
                  {calendars.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </label>
              <div className="md-two-col">
                <label className="md-label">
                  Start
                  <input type="datetime-local" className="md-input" value={eventDraft.startTime}
                    onChange={(ev) => setEventDraft((c) => c ? { ...c, startTime: ev.target.value } : c)} />
                </label>
                <label className="md-label">
                  End
                  <input type="datetime-local" className="md-input" value={eventDraft.endTime}
                    onChange={(ev) => setEventDraft((c) => c ? { ...c, endTime: ev.target.value } : c)} />
                </label>
              </div>

              {/* Existing tasks */}
              {eventDraft.existingTasks.length > 0 && (
                <div className="md-tasks-section">
                  <span className="md-tasks-label">Tasks</span>
                  {eventDraft.existingTasks.map((t) => (
                    <div key={t.id} className="md-modal-task-row">
                      <input type="checkbox" checked={t.status === 'completed'}
                        onChange={(ev) => { void toggleTask(t.id, ev.target.checked); }} />
                      <span className={t.status === 'completed' ? 'done' : ''}>{t.title}</span>
                      <button type="button" className="md-del-task" onClick={() => { void deleteTask(t.id); }}>✕</button>
                    </div>
                  ))}
                </div>
              )}

              <label className="md-label">
                Add tasks (one per line)
                <textarea className="md-input md-textarea" rows={3} placeholder="Pack bag&#10;Buy flowers"
                  value={eventDraft.taskLines}
                  onChange={(ev) => setEventDraft((c) => c ? { ...c, taskLines: ev.target.value } : c)} />
              </label>
            </div>
            <div className="md-modal-footer">
              <button type="button" className="md-btn primary" onClick={() => { void saveEvent(); }}>Save</button>
              {eventDraft.entryId && (
                <button type="button" className="md-btn danger" onClick={() => { void deleteEvent(); }}>Delete</button>
              )}
              <button type="button" className="md-btn secondary" onClick={() => setEventDraft(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Food modal ── */}
      {foodDraftDay && (
        <div className="md-modal-backdrop" onClick={() => setFoodDraftDay(null)}>
          <div className="md-modal" onClick={(ev) => ev.stopPropagation()}>
            <div className="md-modal-header">
              <h2>{foodDraftDay.charAt(0).toUpperCase() + foodDraftDay.slice(1)}</h2>
              <button type="button" className="md-modal-close" onClick={() => setFoodDraftDay(null)}>✕</button>
            </div>
            <div className="md-modal-body">
              <label className="md-label">
                Dish name
                <input className="md-input" placeholder="e.g. Pasta bolognese" value={foodDraftName}
                  onChange={(ev) => setFoodDraftName(ev.target.value)} />
              </label>
            </div>
            <div className="md-modal-footer">
              <button type="button" className="md-btn primary" onClick={() => { void saveFoodDay(); }}>Save</button>
              <button type="button" className="md-btn secondary" onClick={() => setFoodDraftDay(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
