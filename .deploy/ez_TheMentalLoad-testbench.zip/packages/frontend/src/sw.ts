/// <reference lib="webworker" />

const sw = globalThis as unknown as ServiceWorkerGlobalScope;

sw.addEventListener('install', () => {
  void sw.skipWaiting();
});

sw.addEventListener('activate', (event: any) => {
  event.waitUntil(sw.clients.claim());
});

interface PushPayload {
  title: string;
  body: string;
  url?: string;
  icon?: string;
  badge?: string;
}

sw.addEventListener('push', (event: any) => {
  if (!event.data) return;

  let payload: PushPayload;
  try {
    payload = event.data.json() as PushPayload;
  } catch {
    payload = { title: 'MentalLoad', body: event.data.text() };
  }

  const options = {
    body: payload.body,
    icon: payload.icon ?? '/icon.svg',
    badge: payload.badge ?? '/badge.svg',
    data: { url: payload.url ?? '/' },
    actions: [
      { action: 'open', title: 'Open' },
      { action: 'dismiss', title: 'Dismiss' },
    ],
    vibrate: [100, 50, 100],
    requireInteraction: false,
  } as NotificationOptions;

  event.waitUntil(sw.registration.showNotification(payload.title, options));
});

sw.addEventListener('notificationclick', (event: any) => {
  event.notification.close();

  if (event.action === 'dismiss') return;

  const url: string = (event.notification.data as { url?: string }).url ?? '/';

  event.waitUntil(
    sw.clients
      .matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList: readonly WindowClient[]) => {
        const existing = clientList.find((c) => c.url.includes(sw.location.origin));
        if (existing) {
          return existing.focus();
        }
        return sw.clients.openWindow(url);
      }),
  );
});
